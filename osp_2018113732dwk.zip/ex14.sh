#!/bin/bash
#2022-03-18 김동욱
#select command example

select var in alpha beta gamma
do
	echo $var
done
