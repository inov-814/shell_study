#!/bin/bash
#2022-03-18 김동욱
#iterating over parameters example

for parm
do
	echo $parm
done
